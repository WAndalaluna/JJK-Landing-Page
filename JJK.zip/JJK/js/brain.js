// Fungsi ygan digunakan untuk menambahkan efek animasi ke header saat digulir
window.addEventListener('scroll', function() {
    const header = document.querySelector('header');
    header.classList.toggle('sticky', window.scrollY > 0);
});

// Fungsi yang digunakan untuk menampilkan konfirmasi saat pengguna mengklik link
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(event) {
        event.preventDefault();
        const target = this.getAttribute('href');
        const confirmation = confirm(`Anda akan dialihkan ke halaman ${target}. Lanjutkan?`);
        if (confirmation) {
            window.location.href = target;
        }
    });
});

// Fungsi yang digunakan untuk menampilkan pesan sambutan saat halaman dimuat
window.onload = function() {
    alert('Selamat datang di website Jujutsu Kaisen!');
};